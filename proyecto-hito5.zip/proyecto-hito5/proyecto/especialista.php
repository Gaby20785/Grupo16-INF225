<?php
    require_once('config/config.php');

    // Consultar boletines desde la base de datos
    $query = "SELECT * FROM boletines";
    $result = $conexion->query($query);

    if (isset($_GET['ID_boletin'])) {
        $id_boletin = $_GET['ID_boletin'];
    
        // Consultar el boletín seleccionado
        $query = "SELECT * FROM boletines WHERE ID_boletin = ?";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("i", $id_boletin);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
    
            // Insertar el boletín en la tabla aceptados
            $titulo = $row['Categoria'] . ' ' . $row['numero'];
            $imagen = $row['imagen'];
            $url = $row['path'];
    
            // Insertar en la tabla aceptados
            $insert_query = "INSERT INTO aceptados (titulo, imagen, url) VALUES (?, ?, ?)";
            $insert_stmt = $conexion->prepare($insert_query);
            $insert_stmt->bind_param("sss", $titulo, $imagen, $url);
            $insert_stmt->execute();
    
            // Eliminar el boletín de la tabla boletines
            $delete_query = "DELETE FROM boletines WHERE ID_boletin = ?";
            $delete_stmt = $conexion->prepare($delete_query);
            $delete_stmt->bind_param("i", $id_boletin);
            $delete_stmt->execute();
    
            // Redirigir después de la validación
            header("Location: init.html");
            exit();
        } else {
            echo "Boletín no encontrado.";
        }
    }

?>


<!doctype html>
<html lang="en">
  <head>
    <link rel="icon" href="media/fia.png" type="image/png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Especialista</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  
    <div class="container-fluid">
        <div class="row mt-5 ms-4">
            <div class="col-auto">
                <h1 class="d-inline">Validación de boletines</h1>
            </div>
            <div class="col-auto">
                <a href="init.html" class="btn btn-secondary">Volver</a>
            </div>
        </div>

        <div class="row mt-5 ms-4">
            <div class="col">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Categoría</th>
                            <th>Parametros</th>
                            <th>Fuentes</th>
                            <th>Retroalimentacion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            while($row = $result->fetch_assoc()){
                        ?>
                        <tr>
                            <td><?php echo $row['ID_boletin']; ?></td>
                            <td><?php echo $row['Categoria']; ?></td>
                            <td><?php echo $row['parametros']; ?></td>
                            <td><?php echo $row['Fuentes']; ?></td>
                            <td><?php echo $row['Retroalimentacion']; ?></td>
                            <td>
                                <a href=<?php echo $row['path']; ?> class="btn btn-primary me-2">Ver</a>
                            </td>
                            <td>
                                <a href="retroalimentar.php?ID_boletin=<?php echo $row['ID_boletin']; ?>" class="btn btn-warning me-2">Retroalimentar</a>
                            </td>
                            <td>
                                <a href="especialista.php?ID_boletin=<?php echo $row['ID_boletin']; ?>" class="btn btn-success">Validar</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="user-storage.js"></script>

    </body>
</html>