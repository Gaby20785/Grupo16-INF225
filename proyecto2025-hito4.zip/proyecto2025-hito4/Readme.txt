Instrucciones:
*Instalar las dependencias para python: mysql-connector-python, requests, beautifulsoup4.

	Para esto basta con escribir en la consola:
		pip install mysql-connector-python
		pip install requests
		pip install beautifulsoup4

*Llevar el archivo "proyecto" a htdocs en XAMPP.

Nota: Dentro hay una carpeta 'config' con un archivo 'config.php' que tiene el usuario y contraseña por defecto para ingresar a la base de datos,
si tienen un usuario o contraseña en especifico deben cambiar esos apartados, y también deben cambiarlos en el archivo scrape.py.

*Abrir el panel de control de Xampp e iniciar Apache y MySQL

*Abrir el admin de MySQL y crear una nueva base de datos llamada 'boletines', seleccionar la base de datos e importar el archivo boletines.sql

*Ingresar a http://localhost/proyecto/init.html

*Ahora cuando se ingrese a la sección de parámetros y fuentes, se pueden agregar una de estas dos fuentes (o ambas):
	https://www.agritechfuture.com/
	https://www.agritechtomorrow.com/products.php'

Y se recopilarán noticias y/o productos en sus respectivas tablas en la base de datos.

Nota: Sólo hay 6 productos en la segunda página, en la página de noticias hay muchas pero solo dejé las primeras 20 para que no tarde demasiado.
----------------------------------------------------------------