This is where language files should be placed.

Please DO NOT translate these directly, use this service instead: https://crowdin.com/project/tinymce
