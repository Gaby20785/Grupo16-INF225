<?php
    require_once('config/config.php');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $fuentes = $_POST['fuentes'];
  
      // Guardar las fuentes en un archivo temporal para que el script Python pueda leerlas
      $fuentesFile = 'fuentes.txt';
      file_put_contents($fuentesFile, $fuentes);
  
      // Llamar al script Python para realizar el web scraping
      $output = shell_exec("python scrape.py $fuentesFile");
      
      //echo "Web scraping realizado. Datos almacenados en la base de datos.";

      echo '<div class="alert alert-success" role="alert">
              Web scraping realizado. Datos almacenados en la base de datos.
            </div>';
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="/script.js"></script>
  <style>
    @import url("css/styles1.css");
  </style>
  <!--bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
  <!--bootstrap -->
  <body style="background-image: url(https://cdn.glitch.global/f624dee9-81bf-4f9d-983d-ac102ffdfab7/fondo?v=1727044433376); background-repeat: no-repeat; background-size: cover;">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <h1>&nbsp Creación de boletines</h1>

  <!-- Cambiar el action para que apunte a /generar-pdf  action="/generar-pdf"-->
  <form class="parameters" method="POST">
    <div class="form-group">
      <label class="form-label" for="pclave">Palabras clave:</label>
      <textarea required placeholder="Palabra clave 1, palabra clave 2, ..." class="form-input" name="pclave" id="pclave"></textarea>
    </div>

    <div class="form-group">
      <label class="form-label" for="fuentes">Fuentes:</label>
      <textarea required placeholder="Fuente 1, fuente 2, ..." class="form-input" name="fuentes" id="fuentes"></textarea>
    </div>
    
    <button class="form-button" type="submit">Generar PDF</button> 
  </form>
  <!-- Botón atrás -->

  <button class="button" onclick="location.href='init.html'">
    <div class="button-box">
      <span class="button-elem">
        <svg viewBox="0 0 46 40" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M46 20.038c0-.7-.3-1.5-.8-2.1l-16-17c-1.1-1-3.2-1.4-4.4-.3-1.2 1.1-1.2 3.3 0 4.4l11.3 11.9H3c-1.7 0-3 1.3-3 3s1.3 3 3 3h33.1l-11.3 11.9c-1 1-1.2 3.3 0 4.4 1.2 1.1 3.3.8 4.4-.3l16-17c.5-.5.8-1.1.8-1.9z"
          ></path>
        </svg>
      </span>
      <span class="button-elem">
        <svg viewBox="0 0 46 40">
          <path
            d="M46 20.038c0-.7-.3-1.5-.8-2.1l-16-17c-1.1-1-3.2-1.4-4.4-.3-1.2 1.1-1.2 3.3 0 4.4l11.3 11.9H3c-1.7 0-3 1.3-3 3s1.3 3 3 3h33.1l-11.3 11.9c-1 1-1.2 3.3 0 4.4 1.2 1.1 3.3.8 4.4-.3l16-17c.5-.5.8-1.1.8-1.9z"
          ></path>
        </svg>
      </span>
    </div>
    
  </button>

  <div id="response"></div>
</body>
</html>
 